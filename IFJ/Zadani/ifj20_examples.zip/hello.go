// Hello World example in IFJ20
// run it on Merlin by: go run hello.go ifj20.go

package main

func main() {
  print("Hello from IFJ20", "\n")
}